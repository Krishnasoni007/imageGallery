import { Box } from '@mui/system'
import React from 'react'
import { SectionTop } from '../comp/SectionTop'
import sectionImg from "../assets/images/aboutTop.jpg"
import { Container, Typography } from '@mui/material'
import Footer from '../comp/Footer.js'
import Ourteam from '../comp/OurTeam'
const About = () => {
  return (
    <>
    <SectionTop bg={sectionImg}
    title="About" />
    <Container maxWidth="xl">
    <Box className="section_col">
      <Typography
      mb={4}
      className='heading'
      alignLeft
      variant='h3'
      component="h2"
      ><span>Our </span>Vision</Typography>
      <Typography
      variant='subtitle1'
      color="#666666"
      mb={3}
      component="p">Phenix Health is an Australian founded and based company that has entrepreneurship pumping through its veins. We are forever seeking and sourcing opportunities in a drive to make the world we live in whether that be by assisting and empowering our fellow man, seeking efficiencies in the systems that we use in our daily life or making what we do matter to others. We believe in an inclusive business and social model and promote equality of gender, ethnicity and status. We employ and contract internationally and train and operate successfully in a virtual capacity.
      </Typography>
      <Typography
      variant='subtitle1'
      color="#666666"
      mb={3}
      component="p">We believe that all our team have an important role to play and promote a culture of pride and knowledge building.Phenix Health has been at the heart of many and diverse projects and have acquired great knowledge and experience in the Health related field both operationally and socially. Our vision is to offer collaborative solutions and workflows that enable our clients to better service their patients, residents and population.
      </Typography>
      <Typography
      variant='subtitle1'
      color="#666666"
      mb={3}
      component="p">
      We have an office in Australia, Singapore, India and working on developing relationships in China. Our directors have been involved in the health related industry from development of Hospitals and 24/7 operations to Population Health research and Business Strategizing for nearly half a century.Our vision is assisting those implement innovative practices and technologies for scalable efficiency.We are ready to take our expertise all around the world and improve the advancement and long-term viability of the world’s healthcare systems. We are the safe and expert pair of hands medical professionals need to handle their medical administration.
      </Typography>
    </Box>
    <Box className="section_col" align="right">
      <Typography
      mb={4}
      className='heading'
      variant='h3'
      component="h2"
      ><span>Our </span>Journey</Typography>
      <Typography
      variant='subtitle1'
      color="#666666"
      mb={3}
      component="p">Phenix Health Pty Ltd was founded in 2015 by Gillian Alexis & James Davies who have a long history in the set up and management of Medical Technology development, workflow solutions for 24/7 Home Care services across Australia for both Low acuity cases, Aged Care, Emergency services in metro, regional and remote locations. Following a period of R&D by Phenix Health in an endeavour to assist those in regional worked together with large health organisation Primary Health Care Ltd to develop an integrated workflow, systems and technologies approach to the service delivery of Doctor To You P/L (DTY) & Phenix Health P/L 24/7-365 medical home visit service model. During this period much development took place with additional technology advancements and applications that broadened the scope and opportunities into market.
      </Typography>
      <Typography
      variant='subtitle1'
      color="#666666"
      mb={3}
      component="p">The combined team employs over 30 staff and has contracts with over 70 doctors. It has offices in both Gold Coast & Brisbane but has operational capacity in several countries. In Australia, the company now has an operational presence in Melbourne, Sydney, Adelaide, Perth, Darwin and has contracted and partnered with several rural community clinics, emergency services, and aged care facilities.
      </Typography>
      <Typography
      variant='subtitle1'
      color="#666666"
      mb={3}
      component="p">
      Doctor To You was founded in March 2014 following extensive market research and experience in the General Practice sector in metro and regional areas. Doctor To You has participated in many programs and has developed customised software programs that have enabled the delivery of a 24/7-365 home care service throughout Australia. It is through the desire to continually seek ways of improving DTY service delivery that it was realised that there was a need to develop a software that could provides access for a patient to a medical professional through telehealth.
      </Typography>
    </Box>
    </Container>
    <Box className="section-col">
     <Ourteam />
    </Box>
    <Footer />
    </>
  )
}

export default About
