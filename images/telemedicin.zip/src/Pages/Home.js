import React from 'react'
import Hero from '../comp/home/Hero'
import About_sec from '../comp/home/About_sec'
import Services from '../comp/home/Services'
import Partners from '../comp/home/Partners'
import Footer from '../comp/Footer'
const Home = () => {
  return (
    <>
    <Hero></Hero>
    <About_sec 
    title="One Month Trial Available"
    para="Limited time only for GPs, Specialists and Allied Health Professionals. First 5 consults free to your patients. Free entry into the Telehealth system."
    ></About_sec>
    <Services></Services>
    <Partners></Partners>
    <Footer></Footer>
    </>
  )
}

export default Home