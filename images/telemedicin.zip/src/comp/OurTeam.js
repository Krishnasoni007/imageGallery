import React, {Component} from 'react'
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import { Box, Container } from '@mui/system';
import { Typography } from '@mui/material';
import teammember from '../assets/images/teammember.jpg'
// this area is for custome arrows 
function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#00B3FE", width: "40px",height: "40px", display:"flex",justifyContent: "center", alignItems: "center", borderRadius:"50%" }}
        onClick={onClick}
      />
    );
  }
  
  function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#00B3FE",width: "40px", zIndex:9,height: "40px", display:"flex",justifyContent: "center", alignItems: "center", borderRadius:"50%" }}
        onClick={onClick}
      />
    );
  }
  
export default class Ourteam extends Component {
    render() {
      var settings = {
        dots: false,
        adaptiveHeight: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        initialSlide: 0,
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />,
        responsive: [
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 1,
              infinite: true,
              dots: false
            }
          },
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1,
              initialSlide: 1
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ]
      };
      return (
        <div className='section_col ourteam'>
          <Container maxWidth="xl" sx={{mb:10}} >
            <Slider {...settings}>
                <Box sx={{pr: 0}}>
                    <Box className="team-col" sx={{ background:`url(${teammember})no-repeat center center/cover`}}>
                        <Box className="team-cell" color="white">
                          <Box className="typo">
                          <Typography variant='h4' component='h4'>hello</Typography>
                          <Typography variant='p' component='p'>hello</Typography>
                          </Box>
                        </Box>
                    </Box>
                </Box>
                <Box sx={{pr: 0}}>
                    <Box className="team-col" sx={{ background:`url(${teammember})no-repeat center center/cover`}}>
                        <Box className="team-cell" color="white">
                          <Box className="typo">
                          <Typography variant='h4' component='h4'>hello</Typography>
                          <Typography variant='p' component='p'>hello</Typography>
                          </Box>
                        </Box>
                    </Box>
                </Box>
                <Box sx={{pr: 0}}>
                    <Box className="team-col" sx={{ background:`url(${teammember})no-repeat center center/cover`}}>
                        <Box className="team-cell" color="white">
                          <Box className="typo">
                          <Typography variant='h4' component='h4'>hello</Typography>
                          <Typography variant='p' component='p'>hello</Typography>
                          </Box>
                        </Box>
                    </Box>
                </Box>
                <Box sx={{pr: 0}}>
                    <Box className="team-col" sx={{ background:`url(${teammember})no-repeat center center/cover`}}>
                        <Box className="team-cell" color="white">
                          <Box className="typo">
                          <Typography variant='h4' component='h4'>hello</Typography>
                          <Typography variant='p' component='p'>hello</Typography>
                          </Box>
                        </Box>
                    </Box>
                </Box>
                <Box sx={{pr: 0}}>
                    <Box className="team-col" sx={{ background:`url(${teammember})no-repeat center center/cover`}}>
                        <Box className="team-cell" color="white">
                          <Box className="typo">
                          <Typography variant='h4' component='h4'>hello</Typography>
                          <Typography variant='p' component='p'>hello</Typography>
                          </Box>
                        </Box>
                    </Box>
                </Box>
                <Box sx={{pr: 0}}>
                    <Box className="team-col" sx={{ background:`url(${teammember})no-repeat center center/cover`}}>
                        <Box className="team-cell" color="white">
                          <Box className="typo">
                          <Typography variant='h4' component='h4'>hello</Typography>
                          <Typography variant='p' component='p'>hello</Typography>
                          </Box>
                        </Box>
                    </Box>
                </Box>
            </Slider>
          </Container>
        </div>
      );
    }
  }
