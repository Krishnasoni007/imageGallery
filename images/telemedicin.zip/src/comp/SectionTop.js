import { Typography } from '@mui/material'
import { Box } from '@mui/system'
import React from 'react'

export const SectionTop = (section) => {
  return (
    <Box sx={{background: `url(${section.bg})no-repeat center center/cover`, height: "40vh", minHeight:"250px", position:'relative'}}>
        <Typography variant='h3' component="h2" sx={{background: "white", position: "absolute", bottom: "0px", padding: "15px 20px", right: "0px", color: "#00b3fe"}}>{section.title}</Typography>
    </Box>
  )
}
