import React, {Component} from 'react'
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import { Box, Container } from '@mui/system';
import p1 from '../../assets/images/p1 (1).png'
import p2 from '../../assets/images/p1 (1).jpg'
import p3 from '../../assets/images/p1 (3).png'
import p4 from '../../assets/images/p1 (4).png'
import p5 from '../../assets/images/p1 (2).png'
// this area is for custome arrows 
function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#00B3FE", width: "40px",height: "40px", display:"flex",justifyContent: "center", alignItems: "center", borderRadius:"50%" }}
        onClick={onClick}
      />
    );
  }
  
  function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#00B3FE",width: "40px", zIndex:9,height: "40px", display:"flex",justifyContent: "center", alignItems: "center", borderRadius:"50%" }}
        onClick={onClick}
      />
    );
  }
  
export default class Partners extends Component {
    render() {
      var settings = {
        dots: false,
        adaptiveHeight: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        initialSlide: 0,
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />,
        responsive: [
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 1,
              infinite: true,
              dots: false
            }
          },
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1,
              initialSlide: 1
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ]
      };
      return (
        <div className='section_col'>
          <Container maxWidth="xl" sx={{mb:10}} >
            <Slider {...settings}>
                <Box sx={{pr: 1}}>
                    <Box className="partners-col" sx={{p: 1}}>
                        <img src={p1} alt="" width="100%" />
                    </Box>
                </Box>
                <Box sx={{pr: 1}}>
                    <Box className="partners-col" sx={{p: 1}}>
                        <img src={p2} alt="" width="100%" />
                    </Box>
                </Box>
                <Box sx={{pr: 1}}>
                    <Box className="partners-col" sx={{p: 1}}>
                        <img src={p3} alt="" width="100%" />
                    </Box>
                </Box>
                <Box sx={{pr: 1}}>
                    <Box className="partners-col" sx={{p: 1}}>
                        <img src={p4} alt="" width="100%" />
                    </Box>
                </Box>
                <Box sx={{pr: 1}}>
                    <Box className="partners-col" sx={{p: 1}}>
                        <img src={p5} alt="" width="100%" />
                    </Box>
                </Box>
                <Box sx={{pr: 1}}>
                    <Box className="partners-col" sx={{p: 1}}>
                        <img src={p1} alt="" width="100%" />
                    </Box>
                </Box>
            </Slider>
          </Container>
        </div>
      );
    }
  }