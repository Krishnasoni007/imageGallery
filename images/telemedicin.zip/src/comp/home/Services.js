import React, {Component} from 'react'
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import Service from './Service';
import { width } from '@mui/system';
// this area is for custome arrows 
function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#333333", right: "0px", bottom: "0px", width: "60px", transform:"translate(0px, 0px)", top:'inherit',height: "60px", display:"flex",justifyContent: "center", alignItems: "center" }}
        onClick={onClick}
      />
    );
  }
  
  function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#333333",left:"inherit", right: "60px", bottom: "0px", width: "60px", transform:"translate(0px, 0px)", zIndex:9, top:'inherit',height: "60px", display:"flex",justifyContent: "center", alignItems: "center", borderRight:"2px solid white" }}
        onClick={onClick}
      />
    );
  }
  
export default class Services extends Component {
    render() {
      var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        initialSlide: 0,
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />,
        responsive: [
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 1,
              infinite: true,
            }
          },
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1,
              initialSlide: 1
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ]
      };
      return (
        <div className='section_col'>
          <Slider {...settings}>
            <Service 
            background="https://images.unsplash.com/photo-1664265694638-e858db3fd16b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            title="Virtual Healthcare Designers"
            para="Health workflow designer for Virtual Healthcare settings (Aged Care and Remote Clinics using integrated software and platforms)."
            overlay="#00b3fea3"
            />
            <Service 
            background="https://images.unsplash.com/photo-1664265694638-e858db3fd16b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            title="Virtual Healthcare Designers"
            para="Health workflow designer for Virtual Healthcare settings (Aged Care and Remote Clinics using integrated software and platforms)."
            overlay="#01EDC9a3"
            />
            <Service 
            background="https://images.unsplash.com/photo-1664265694638-e858db3fd16b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            title="Virtual Healthcare Designers"
            para="Health workflow designer for Virtual Healthcare settings (Aged Care and Remote Clinics using integrated software and platforms)."
            overlay="#238BFAa3"
            />
            <Service 
            background="https://images.unsplash.com/photo-1664265694638-e858db3fd16b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            title="Virtual Healthcare Designers"
            para="Health workflow designer for Virtual Healthcare settings (Aged Care and Remote Clinics using integrated software and platforms)."
            overlay="#00b3fea3"
            />
            <Service 
            background="https://images.unsplash.com/photo-1664265694638-e858db3fd16b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            title="Virtual Healthcare Designers"
            para="Health workflow designer for Virtual Healthcare settings (Aged Care and Remote Clinics using integrated software and platforms)."
            overlay="#01EDC9a3"
            />
            <Service 
            background="https://images.unsplash.com/photo-1664265694638-e858db3fd16b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            title="Virtual Healthcare Designers"
            para="Health workflow designer for Virtual Healthcare settings (Aged Care and Remote Clinics using integrated software and platforms)."
            overlay="#238BFAa3"
            />
            <Service 
            background="https://images.unsplash.com/photo-1664265694638-e858db3fd16b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            title="Virtual Healthcare Designers"
            para="Health workflow designer for Virtual Healthcare settings (Aged Care and Remote Clinics using integrated software and platforms)."
            overlay="#00b3fea3"
            />
          </Slider>
        </div>
      );
    }
  }