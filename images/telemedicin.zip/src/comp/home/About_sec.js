import React from 'react'
import Grid from '@mui/material/Grid'; // Grid version 1
import { Container, spacing } from '@mui/system';
import { Link } from 'react-router-dom';
import about_img from '../../assets/images/about.png'
import { Typography } from '@mui/material';
const About_sec = (about) => {
  return (
    <div className='section_col'>
       <Container maxWidth="xl">
            <Grid container spacing={4}>
                    <Grid item xs={12} md={6}>
                        <img src={about_img} alt={about_img} width="100%"/>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Typography variant="h3" component="h2" className='heading' sx={{ mb:3 }}><span>Free</span> {about.title}</Typography>
                        <Typography variant="subtitle1" component="p" className='para' sx={{ mb:6 }}>{about.para}</Typography>
                        <Link to='/home' className='brand-btn'>MESSAGE US</Link>
                    </Grid>
            </Grid>
       </Container>
    </div>
  )
}

export default About_sec
