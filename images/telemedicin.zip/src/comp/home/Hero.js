import React from 'react';
import Carousel from 'react-material-ui-carousel'
import { Paper, Container, Grid} from '@mui/material'
import heroimg from '../../assets/images/backgournd.jpg'
import {Link} from 'react-router-dom'
// import { border, display, height, margin, width } from '@mui/system';
function Hero(props)
{
    return (
        <Carousel 
            navButtonsProps={{          // Change the colors and radius of the actual buttons. THIS STYLES BOTH BUTTONS
              style: {
                  display: "none"
              }
          }}
          indicatorIconButtonProps={{
            style: {
                color: 'transparent',       // 3
                border: '4px solid white',
                height: "25px", 
                margin: "10px 5px ",
                width: "25px",
            }
          }}
          activeIndicatorIconButtonProps={{
              style: {
                border: '4px solid #00B3FE',
              }
          }}
          indicatorContainerProps={{
              style: {
                  position: 'absolute',
                  display: 'flex',
                  flexDirection: "column",
                  top: "50%",
                  right: "0%",
                  transform: "translate(-50%, -50%)",
                  zIndex: "99",
                  width: "40px"
                  
              }
      
          }}
          animation="slide"
          interval="6000"
        >
            {
                <Paper className='hero' style={{background: `url(${heroimg})no-repeat center center/cover`}}>
                  <Container maxWidth="xl">
                    <Grid container>
                      <Grid item xs={12} md={6}>
                          <div className="hero-details">
                            <h1 className="heroTitle">Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam pariatur odit similique!</h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed quod vitae accusantium obcaecati numquam! Ex modi, minus repellendus velit libero dolorem quaerat.</p>
                            <Link className="brand-btn">Find Out More</Link>
                          </div>
                      </Grid>
                    </Grid>
                  </Container>
                </Paper>
            }
            {
                <Paper className='hero' style={{background: `url(${heroimg})no-repeat center center/cover`}}>
                  <Container maxWidth="xl">
                    <Grid container>
                      <Grid item xs={12} md={6}>
                          <div className="hero-details">
                            <h1 className="heroTitle">Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam pariatur odit similique!</h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed quod vitae accusantium obcaecati numquam! Ex modi, minus repellendus velit libero dolorem quaerat.</p>
                            <Link className="brand-btn">Find Out More</Link>
                          </div>
                      </Grid>
                    </Grid>
                  </Container>
                </Paper>
            }
            {
                <Paper className='hero' style={{background: `url(${heroimg})no-repeat center center/cover`}}>
                  <Container maxWidth="xl">
                    <Grid container>
                      <Grid item xs={12} md={6}>
                          <div className="hero-details">
                            <h1 className="heroTitle">Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam pariatur odit similique!</h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed quod vitae accusantium obcaecati numquam! Ex modi, minus repellendus velit libero dolorem quaerat.</p>
                            <Link className="brand-btn">Find Out More</Link>
                          </div>
                      </Grid>
                    </Grid>
                  </Container>
                </Paper>
            }
        </Carousel>
    )
}
export default Hero