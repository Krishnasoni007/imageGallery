import React from 'react'
import { Typography, Grid } from '@mui/material';
import Services from './Services';
const Service = (service) => {
  return (
    <div
    style={{background: `url(${service.background})no-repeat center center/cover`, height: "calc(300px + 10vw)"}}
    className="sercive_card"
    >
        <div className="overlay" style={{backgroundColor: `${service.overlay}`}}>
        <Typography variant='h4' component="h3" align='center' sx={{mb: 3}}>
        {service.title}
        </Typography>
        <Typography variant='p' component="p" align='center'>
        {service.para}
        </Typography>
        </div>
    </div>
  )
}

export default Service
