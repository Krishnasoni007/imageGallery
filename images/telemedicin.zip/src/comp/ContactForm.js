import React, { useRef, useState } from 'react'
import emailjs from '@emailjs/browser';
import {Box, TextField, Link, Typography} from "@mui/material"
const Result = () =>{
    return(
        <>Your Message has Been successfully sent</>
    )
}
const ContactForm = () => {
    
    const [result, showResult] = useState(false);
    const form = useRef();
    const sendEmail = (e) => {
    e.preventDefault();

    emailjs.sendForm('service_efyjq2b', 'template_2acpcn8', form.current, 'GaUN7mPpwB8knLY0p')
      .then((result) => {
          console.log(result.text);
      }, (error) => {
          console.log(error.text);
      });
      e.target.reset();
      showResult(true);
      setTimeout(() => {
        showResult(false);
      }, 8000);
  };
  return (
    <Box 
    component="form"
    ref={form}
    onSubmit={sendEmail}
    >
        <TextField size="small" id="fullWidth" name='fullname' label="Your Name" variant="filled" sx={{backgroundColor: "#6A6A6A", input:{color: 'white'}, label: {color: 'white'}, mb: 2,width: "100%" }} />
        <TextField size="small" id="fullWidth" name='email' label="Your Email" variant="filled" sx={{backgroundColor: "#6A6A6A", input:{color: 'white'}, label: {color: 'white'}, mb: 2,width: "100%" }} />
        <TextField size="small" id="fullWidth" name="phone" label="Your Phone No" variant="filled" sx={{backgroundColor: "#6A6A6A", input:{color: 'white'}, label: {color: 'white'}, mb: 2,width: "100%" }} />
        <TextField
        id="filled-multiline-static"
        label="Message"
        multiline
        name="message"
        rows={4}
        variant="filled"
        size="small"
        sx={{backgroundColor: "#6A6A6A",color: "white", textarea:{color: 'white'}, label: {color: 'white'}, mb: 2,width: "100%" }}
        />
        <button type='submit' className='brand-btn btn-lg-size' px={0} mb={2} sx={{width:"100% !important", textAlign: "center !important"}}>Submit</button>
        <Typography my={4} variant='h5'  component="h4" className='fheading'>{result ? <Result/> : null}</Typography>
    </Box>
  )
}

export default ContactForm
