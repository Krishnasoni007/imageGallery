import React from 'react';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import footer_logo from '../assets/images/flogo.png'
import { Typography } from '@mui/material';
import { FaFacebookF, FaYoutube } from 'react-icons/fa';
import {AiFillInstagram} from 'react-icons/ai'
import {BsTwitter} from 'react-icons/bs'
import TextField from '@mui/material/TextField';
import TextareaAutosize from '@mui/base/TextareaAutosize';
import ContactForm from './ContactForm';
export default function Footer() {
  return (
    <footer>
      <Box
        // px={{ xs: 3, sm: 10 }}
        pt={{ xs: 3, sm: 6 }}
        bgcolor="#333333"
        color="white"
      >
        <Container maxWidth="xl">
          <Grid container spacing={5}>
            <Grid item xs={12} lg={3} md={3} sm={6}>
              <Box sx={{mb:4}}><img src={footer_logo} alt="" className='flogo'/></Box>
              <Box>
                <Typography sx={{mb: 2}} variant='h5' component="h5" className='fheading'>follow us at</Typography>
                <Grid container>
                  <Box mr={3}><Link href='#' sx={{color: "white"}}><FaFacebookF size={24}/></Link></Box>
                  <Box mr={3}><Link href='#' sx={{color: "white"}}><BsTwitter size={24}/></Link></Box>
                  <Box mr={3}><Link href="#" sx={{color: "white"}}><FaYoutube size={24}/></Link></Box>
                  <Box mr={3}><Link href="#" sx={{color: "white"}}><AiFillInstagram size={24}/></Link></Box>
                </Grid>
              </Box>
            </Grid>
            <Grid item xs={12} lg={2} md={3} sm={6}>
              <Box><Typography sx={{mb: 2}} variant='h5' component="h5" className='fheading'>MENU</Typography></Box>
              <Box mb={2}>
                <Link href="/" color="inherit" className='f-link'>
                Support
                </Link>
              </Box>
              <Box mb={2}>
                <Link href="/" color="inherit" className='f-link'>
                Contact
                </Link>
              </Box>
              <Box mb={2}>
                <Link href="/" color="inherit" className='f-link'>
                Pallo
                </Link>
              </Box>
              <Box mb={2}>
                <Link href="/" color="inherit" className='f-link'>
                ResApp
                </Link>
              </Box>
            </Grid>
            <Grid item xs={12} lg={3} md={3} sm={6}>
              <Box><Typography sx={{mb: 2}} variant='h5' component="h5" className='fheading'>CONTACT</Typography></Box>
              <Box mb={2}>
                <Link href="/" color="inherit" className='f-link'>
                p: 1300 900 863
                </Link>
              </Box>
              <Box mb={2}>
                <Link href="/" color="inherit" className='f-link'>
                f: 07 3054 6688
                </Link>
              </Box>
              <Box mb={2}>
                <Link href="/" color="inherit" className='f-link'>
                e: info@phenixhealth.com.au
                </Link>
              </Box>
              <Box mb={2}>
                <Link href="/" color="inherit" className='f-link'>
                PO Box 3323, Newstead 4006
                </Link>
              </Box>
            </Grid>
            <Grid item xs={12} lg={4} md={3} sm={6}>
            <Box><Typography sx={{mb: 2}} variant='h5' component="h5" className='fheading'>MESSAGE</Typography></Box>
              <ContactForm></ContactForm>
            </Grid>
          </Grid>
        </Container>
        <Box textAlign="center" py={{ xs: 2, sm: 3 }} className="copy" bgcolor="#252525">
              © 2022 All rights reserved. telemedicine australia
        </Box>
      </Box>
    </footer>
  );
}