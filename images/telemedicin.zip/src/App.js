import React from 'react';
import './App.css';
import {Route, Routes, Link} from 'react-router-dom'
import Home from './Pages/Home';
import About from './Pages/About';
import ResponsiveAppBar from './comp/ResponsiveAppBar';
import { Sugar } from 'react-preloaders';
// import '../scss/styles.js';
import './assets/stylesheet/style.scss';
function App() {
  return (
    <>
    <ResponsiveAppBar/>
    <Routes>
      <Route exact='true' path='/' element={<Home />} />
      <Route exact='true' path='/home' element={<Home />} />
      <Route exact='true' path='/about' element={<About />} />
      {/* <Sugar color={'#f7f7f7'} background="#f7f7f7" />; */}
    </Routes>
    </>
  );
}

export default App;
