import { useEffect } from 'react';

function MyComponent() {
  const handleRightDrag = (event) => {
    if (event.button === 2) {
      // This is a right drag event!
      // You can use this event handler to trigger some behavior, such as
      // removing the component from the DOM or triggering some other action
    }
  };

  // Attach the event listener when the component mounts
  useEffect(() => {
    const name = document.getElementById('new');
    // Add the event listener
    name.addEventListener('drag', handleRightDrag);

    // Remove the event listener when the component unmounts
    return () => {
      name.removeEventListener('drag', handleRightDrag);
    };
  }, [handleRightDrag]);

  // Render the component
  return (
    <div id='new'>
      Right drag to remove me!
    </div>
  );
}
export default MyComponent