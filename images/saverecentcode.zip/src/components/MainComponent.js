import React from "react";

const MainComponent = (props) => {
  return (
    <div className="main_div p-4" ref={props.containerRef}>
      <style>{HTMLstyle}</style>

      {list.map((item, index) => (
        <div
          key={index}
          data-position={index}
          draggable
          onDragStart={onDragStart}
          ondrag
          onDragOver={onDragOver}
          onDrop={onDrop}
          onDragExit={onDragLeave}
        >
          <div>
            <div
              className="select-text"
              dangerouslySetInnerHTML={{ __html: item.text }}
            />
          </div>
        </div>
      ))}
    </div>
  );
};

export default MainComponent;
