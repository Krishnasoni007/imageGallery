import React, { useRef } from "react";
import { Editor } from "@tinymce/tinymce-react";

export default function EditorComp({editorContent, initialValue}) {
  const editorRef = useRef(null);
  const log = () => {
      editorContent(editorRef.current.getContent());
  };
  return (
      <div>
        <Editor
          apiKey="c9bez6txom2murfiq226st4ozhptfx6fv1tqcra9miv4mbnj"
          onInit={(evt, editor) => (editorRef.current = editor)}
          initialValue={initialValue}
          onEditorChange={log}
          init={{
            height: 500,
            menubar: true,
            plugins: [
              "a11ychecker",
              "advlist",
              "advcode",
              "advtable",
              "autolink",
              "checklist",
              "export",
              "lists",
              "link",
              "image",
              "charmap",
              "preview",
              "anchor",
              "searchreplace",
              "visualblocks",
              "powerpaste",
              "fullscreen",
              "formatpainter",
              "insertdatetime",
              "media",
              "table",
              "help",
              "wordcount",
            ],
            toolbar1:
              "casechange blocks | bold italic underline backcolor forecolor | " +
              "alignleft aligncenter alignright alignjustify | ",
            toolbar2: 
              "bullist numlist checklist outdent indent | removeformat | a11ycheck table help",
          }}
        />
      </div>
  );
}
