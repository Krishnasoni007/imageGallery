import React, { useState, Fragment, useRef, useEffect } from "react";
import { RadioGroup, Switch } from "@headlessui/react";
import { v4 as uuidv4 } from "uuid";
import EditorComp from "./EditorComp";
import MainSidebar from "./MainSidebar";
import Modal from "./Modal";
import ReactSlider from "react-slider";
import SignaturePad from "signature_pad";
export default function NoCodeHome() {

  // this function is for download html code
  const containerRef = useRef(null);
  const HTMLstyle = `*{
         margin: 0px;
         padding: 0px;
     }
     .container{
        max-width: 1400px;
        padding: 10px 25px ;
        margin: 10px auto;
     }
     .simpleInput{
        border:none;
        color: gray;
        background: transparent;
        padding: 5px 8px;
        border-bottom: 2px solid gray;
    }
    .simpleInput:focus{
        border: none;
        outline: none;
        border-bottom: 2px solid gray;
    }
    .simpleInput:focus-visible{
        border: none;
        outline: none;
        border-bottom: 2px solid gray;
     }
     .sign__prev{
        position: relative;
        height: 200px;
        width: 100%;
        cursor: pointer;
        overflow: hidden;
        border-radius: 0.5rem;
        border-width: 2px;
        border-style: dashed;
        --tw-border-opacity: 1;
        border-color: rgb(107 114 128 / var(--tw-border-opacity));
    }
    .sign__prev .sign__prev_p {
        position: absolute;
        top: 100%;
        left: 0px;
        display: flex;
        height: 100%;
        width: 100%;
        cursor: pointer;
        align-items: center;
        justify-content: center;
        border-style: none;
        --tw-bg-opacity: 1;
        background-color: rgb(107 114 128 / var(--tw-bg-opacity));
        font-size: 1.5rem;
        line-height: 2rem;
        --tw-text-opacity: 1;
        color: rgb(255 255 255 / var(--tw-text-opacity));
        transition-duration: 300ms;
    }
    .sign__prev:hover .sign__prev_p {
        top: 0px;
    }
    .signature_col_h {
        margin-bottom: 0.75rem;
        font-size: 1.875rem;
        line-height: 2.25rem;
        --tw-text-opacity: 1;
        color: rgb(107 114 128 / var(--tw-text-opacity));
    }
    .closeCanva {
        position: fixed;
        top: 0px;
        left: 0px;
        z-index: 98;
        height: 100vh;
        width: 100%;
        --tw-bg-opacity: 1;
        background-color: rgb(209 213 219 / var(--tw-bg-opacity));
    }
    .signatureCanva {
        position: absolute;
        top: 0px;
        left: 0px;
        z-index: 99;
        cursor: crosshair;
        --tw-bg-opacity: 1;
        background-color: rgb(255 255 255 / var(--tw-bg-opacity));
    }
    .close__btn {
        position: absolute;
        top: 1rem;
        right: 1rem;
        z-index: 999;
        cursor: pointer;
        border-style: none;
        background-color: transparent;
    }
    .clean__btn {
        position: absolute;
        top: 4rem;
        right: 1rem;
        z-index: 999;
        border-style: none;
        background-color: transparent;
    }
    .approve__btn {
        position: absolute;
        top: 7rem;
        right: 1rem;
        z-index: 999;
        border-style: none;
        background-color: transparent;
    }
    .showSignature {
        height: 200px;
        width: 100%;
        border-radius: 0.5rem;
        border-width: 2px;
        border-style: dashed;
        --tw-border-opacity: 1;
        border-color: rgb(107 114 128 / var(--tw-border-opacity));
        object-fit: contain;
    }
    @media (min-width: 1024px){
        .signature_col {
            width: 50%;
        }
    }
    .tox-notification.tox-notification--in.tox-notification--warning{
      display: none !important; 
    }
     `;
  const [downloadLink, setDownloadLink] = useState("");
  const handleClick = () => {
    const html = containerRef.current.innerHTML;
    const blob = new File([html], "export.html", { type: "text/html" });
    const url = URL.createObjectURL(blob);
    setDownloadLink(url);
    console.log(list);
  };
  // end here
  // this area is for generated html
  let genString = JSON.parse(localStorage.getItem("list"));
  let genHTML = genString;
  if (genString === null) {
    genHTML = [];
  }
  // let genHTML = [];
  // console.log(genHTML);
  const initialDnDState = {
    draggedFrom: null,
    draggedTo: null,
    isDragging: false,
    originalOrder: [],
    updatedOrder: [],
  };
  const [list, setList] = useState(genHTML);
  const [dragAndDrop, setDragAndDrop] = useState(initialDnDState);
  useEffect(() => {
    localStorage.setItem("list", JSON.stringify(list));
  }, [list]);
  // onDragStart fires when an element
  // starts being dragged
  const onDragStart = (event) => {
    const initialPosition = Number(event.currentTarget.dataset.position);
    event.dataTransfer.setData("application/my-app", event.target.id);
    // event.dataTransfer.effectAllowed = "move";
    setDragAndDrop({
      ...dragAndDrop,
      draggedFrom: initialPosition,
      isDragging: true,
      originalOrder: list,
    });

    // Note: this is only for Firefox.
    // Without it, the DnD won't work.
    // But we are not using it.
    event.dataTransfer.setData("text/html", "");
  };

  // onDragOver fires when an element being dragged
  // enters a droppable area.
  // In this case, any of the items on the list
  const onDragOver = (event) => {
    // in order for the onDrop
    // event to fire, we have
    // to cancel out this one
    event.preventDefault();

    let newList = dragAndDrop.originalOrder;

    // index of the item being dragged
    const draggedFrom = dragAndDrop.draggedFrom;

    // index of the droppable area being hovered
    const draggedTo = Number(event.currentTarget.dataset.position);

    const itemDragged = newList[draggedFrom];
    const remainingItems = newList.filter(
      (item, index) => index !== draggedFrom
    );

    newList = [
      ...remainingItems.slice(0, draggedTo),
      itemDragged,
      ...remainingItems.slice(draggedTo),
    ];

    if (draggedTo !== dragAndDrop.draggedTo) {
      setDragAndDrop({
        ...dragAndDrop,
        updatedOrder: newList,
        draggedTo: draggedTo,
      });
    }
  };

  const onDrop = (event) => {
    setList(dragAndDrop.updatedOrder);

    setDragAndDrop({
      ...dragAndDrop,
      draggedFrom: null,
      draggedTo: null,
      isDragging: false,
    });
  };

  const onDragLeave = () => {
    setDragAndDrop({
      ...dragAndDrop,
      draggedTo: null,
    });
  };
  // this is kldald alkdlk adlkalda adkdk 
  const dragover_handler = (ev) => {
    ev.preventDefault();
    // ev.dataTransfer.dropEffect = "move";
  }
  const drop_handler = (ev) => {
    ev.preventDefault();
    // Get the id of the target and add the moved element to the target's DOM
    const data = ev.dataTransfer.getData("application/my-app");
    console.log(data);
    ev.target.appendChild(document.getElementById(data));
  }
  useEffect(() => {
    const dragIntoDiv = document.querySelectorAll('.dragIntoDiv');
    for (let i = 0; i < dragIntoDiv.length; i++) {

    }
  }, [list])
  // this is for text field modal
  const [isTextFieldOpen, setIsTextFieldOpen] = useState(false);
  const [editorData, setEditorData] = useState("");
  const submitTextValue = (e) => {
    e.preventDefault();
    let newid = uuidv4();
    // console.log(newid)
    setList(
      list.concat({
        id: newid,
        text: editorData,
        type: "richText",
        customeStyle: {},
      })
    );
    setIsTextFieldOpen(false);
  };

  function textFieldOpen() {
    setIsTextFieldOpen(true);
  }
  function closeModal() {
    setIsTextFieldOpen(false);
  }
  // end here
  // this area for image field
  const [isImgModalOpen, setISImgModalOpen] = useState(false);
  const [imageUrl, setImageUrl] = useState("");
  const imageAlign = useRef(null);
  const imageSize = useRef(null);
  function imgFieldOpen() {
    setISImgModalOpen(true);
  }
  function imageModalClose() {
    setISImgModalOpen(false);
  }
  // const ImageFieldUload = (e) => {
  //   setImageUrl(URL.createObjectURL(e.target.files[0]));
  // };
  const convertToBase64 = (file) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      setImageUrl(reader.result);
    }
  }
  const AddImageToList = (e) => {
    e.preventDefault();
    let newid = uuidv4();
    const buildHtml = `<div style='display: flex; justify-content:${imageAlign.current.value};'><img style='${imageSize.current.value}' src='${imageUrl}'/></div>`;
    setList(
      list.concat({
        id: newid,
        text: buildHtml,
        type: "image",
        customeStyle: {},
      })
    );
    setImageUrl("");
    setISImgModalOpen(false);
  };
  // end here
  // this area is for input filde
  const [isInputModalOpen, setIsInputModalOpen] = useState(false);
  const inputtype = useRef(null);
  const inputPlaceholder = useRef(null);
  const inputLabel = useRef(null);
  const inputalign = useRef(null);
  const [enabled, setEnabled] = useState(false);
  const [userSelectedText, setUserSelectedText] = useState("");
  const [userSelectedTextId, setUserSelectedTextId] = useState("");
  const selection = window.getSelection();
  const [inputCheck, setInputCheck] = useState(true);
  function inputModalClose() {
    setIsInputModalOpen(false);
  }
  const inputModalOpen = (e) => {
    e.preventDefault();
    if (selection.toString()) {
      const selectedText =
        selection.focusNode.parentElement.closest(".close_remove");
      const endNode = selectedText.getAttribute("data-id");
      setUserSelectedText(selectedText);
      setInputCheck(false);
      setUserSelectedTextId(endNode);
      setIsInputModalOpen(true);
    } else {
      setInputCheck(true);
      setIsInputModalOpen(true);
    }

    // if (startNode && endNode) {
    //     const startParent = startNode.parentElement;
    //     const endParent = endNode.parentElement;

    //     // console.log(startParent);
    //     console.log(endParent);
    //   }
  };
  const inputFormHandler = (e) => {
    e.preventDefault();
    let newid = uuidv4();
    let inputHtml = "";
    const inputt = inputtype.current.value;

    if (selection.toString()) {
      if (inputt === "text") {
        inputHtml = `<input type="text" class="simpleInput"/>`;
      } else if (inputt === "checkbox") {
        inputHtml = '<input type="checkbox" class=""/>';
      } else if (inputt === "number") {
        inputHtml = `<input type="number" class="simpleInput"/>`;
      } else if (inputt === "date") {
        inputHtml = `<input type="date" class="simpleInput"/>`;
      } else if (inputt === "time") {
        inputHtml = `<input type="time" class="simpleInput"/>`;
      } else if (inputt === "address") {
        inputHtml = `<input type="text" class="simpleInput"/>`;
      } else {
        inputHtml = `<input type="text" class="simpleInput"/>`;
      }
      let completeInput = `<label>${inputHtml}</label>`;
      const range = selection.getRangeAt(0);
      range.deleteContents();
      const insideinput = document.createElement("span");
      insideinput.innerHTML = completeInput;
      range.insertNode(insideinput);
      const updatedItems = list.map((item) => {
        if (item.id === userSelectedTextId) {
          return {
            ...item,
            text: userSelectedText.querySelectorAll("div")[0].innerHTML,
          };
        }
        return item;
      });
      setList(updatedItems);
    } else {
      if (inputt === "text") {
        inputHtml = `<input type="text" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
      } else if (inputt === "checkbox") {
        inputHtml = '<input type="checkbox" class=""/>';
      } else if (inputt === "number") {
        inputHtml = `<input type="number" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
      } else if (inputt === "date") {
        inputHtml = `<input type="date" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
      } else if (inputt === "time") {
        inputHtml = `<input type="time" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
      } else if (inputt === "address") {
        inputHtml = `<input type="text" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
      } else {
        inputHtml = `<input type="text" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
      }
      let completeInput = `<label>${inputLabel.current.value}  ${inputHtml}</label>`;
      if (enabled) {
        completeInput = `<label>${inputLabel.current.value}  ${inputHtml}</label>`;
      } else {
        completeInput = `<label>${inputHtml}  ${inputLabel.current.value}</label>`;
      }
      if (inputalign.current.value !== "Alignment") {
        completeInput = `<div style="text-align:${inputalign.current.value};">${completeInput}</div>`;
      }
      setList(
        list.concat({
          id: newid,
          text: completeInput,
          type: "input",
          customeStyle: {},
        })
      );
    }

    setIsInputModalOpen(false);
  };
  // end here
  // this area is for signature input
  const [isSignModalOpen, setIsSignModalOpen] = useState(false);
  const signInputTitle = useRef(null);
  function signModalClose() {
    setIsSignModalOpen(false);
  }
  const signModalOpen = (e) => {
    e.preventDefault();
    setIsSignModalOpen(true);
  };
  const signFormHandler = (e) => {
    e.preventDefault();
    let newid = uuidv4();
    const buildSignHtml = `
        <div class="signature_col">
            <h4 class="signature_col_h">${signInputTitle.current.value}</h4>
            <div class="sign__prev">
                <button class="sign__prev_p">Click To Sign</button>
            </div>
            <div class="closeCanva" id="idelWidth" style='display: none;'>
                <canvas class="signatureCanva" width="300px" height="200px"></canvas>
                <button class="close__btn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style='widht: 2.5rem; height: 2.5rem; color: rgb(55 65 81);'>
                        <path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z" clip-rule="evenodd" />
                    </svg>
                </button>
                <button class="clean__btn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style='widht: 2.5rem; height: 2.5rem; color: rgb(239 68 68);'>
                        <path fill-rule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 013.878.512.75.75 0 11-.256 1.478l-.209-.035-1.005 13.07a3 3 0 01-2.991 2.77H8.084a3 3 0 01-2.991-2.77L4.087 6.66l-.209.035a.75.75 0 01-.256-1.478A48.567 48.567 0 017.5 4.705v-.227c0-1.564 1.213-2.9 2.816-2.951a52.662 52.662 0 013.369 0c1.603.051 2.815 1.387 2.815 2.951zm-6.136-1.452a51.196 51.196 0 013.273 0C14.39 3.05 15 3.684 15 4.478v.113a49.488 49.488 0 00-6 0v-.113c0-.794.609-1.428 1.364-1.452zm-.355 5.945a.75.75 0 10-1.5.058l.347 9a.75.75 0 101.499-.058l-.346-9zm5.48.058a.75.75 0 10-1.498-.058l-.347 9a.75.75 0 001.5.058l.345-9z" clip-rule="evenodd" />
                    </svg>
                </button>
                <button class="approve__btn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style='widht: 2.5rem; height: 2.5rem; color: rgb(34 197 94);'>
                        <path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clip-rule="evenodd" />
                    </svg>
                </button>
            </div>
            <img src="" alt="data url" class="showSignature" style='display:none;' />
        </div>
        `;
    setList(
      list.concat({
        id: newid,
        text: buildSignHtml,
        type: "sign",
        customeStyle: {},
      })
    );
    setIsSignModalOpen(false);
  };
  // end here
  // this function is for remover content from array
  const removerClose = (e) => {
    e.preventDefault();
    let removerid = e.target?.closest("div").getAttribute("data-id");
    let newarray = list.filter((listitem) => listitem.id !== removerid);
    setList([...newarray]);
  };
  // end here
  // this area is for layoutSectionOpen 
  const [islayoutModalOpen, setLayoutModalOpen] = useState(false);
  const closeLayoutModal = (e) => {
    e.preventDefault();
    setLayoutModalOpen(false);
  }
  const layoutSectionOpen = (e) => {
    e.preventDefault();
    setLayoutModalOpen(true);
  }
  const plans = [
    {
      name: 'Startup',
      ram: '12GB',
      cpus: '6 CPUs',
      disk: '160 GB SSD disk',
    },
    {
      name: 'Business',
      ram: '16GB',
      cpus: '8 CPUs',
      disk: '512 GB SSD disk',
    },
    {
      name: 'Enterprise',
      ram: '32GB',
      cpus: '12 CPUs',
      disk: '1024 GB SSD disk',
    },
  ]
  const [selected, setSelected] = useState(plans[0])
  // end here 
  // this are is for style
  const [isStyleModalOpen, setIsStyleModalOpen] = useState(false);
  const [topMarginValue, setTopMarginValue] = useState("");
  const [rightMarginValue, setRightMarginValue] = useState("");
  const [bottomMarginValue, setBottomMarginValue] = useState("");
  const [leftMarginValue, setLeftMarginValue] = useState("");
  const [styleDataId, setStyleDateId] = useState("");

  function styleModalClose() {
    setIsStyleModalOpen(false);
  }
  const deisgnClose = (e) => {
    e.preventDefault();
    setIsStyleModalOpen(true);
    let styleid = e.target?.closest("div").getAttribute("data-id");
    setStyleDateId(styleid);
  };
  const styleHandler = (e) => {
    e.preventDefault();
    const totalMargin = {
      marginTop: `${topMarginValue}px`,
      marginBottom: `${bottomMarginValue}px`,
      marginLeft: `${leftMarginValue}px`,
      marginRight: `${rightMarginValue}px`,
    };
    const updatedItems = list.map((item) => {
      if (item.id === styleDataId) {
        return { ...item, customeStyle: totalMargin };
      }
      return item;
    });
    setList(updatedItems);
    console.log(list);
    setTopMarginValue(0);
    setRightMarginValue(0);
    setBottomMarginValue(0);
    setLeftMarginValue(0);
    setIsStyleModalOpen(false);
  };
  // end here
  // this functin is for update arrary
  const [updateTextField, setUpdateTextField] = useState(false);
  const [isUpdateImgModalOpen, setIsUpdateImgModalOpen] = useState(false);
  const [isUpdateInputModalOpen, setIsUpdateInputModalOpen] = useState(false);
  const [richTextUpdate, setRichTextUpdate] = useState("");
  const [updatedEditorData, setUpdatedEditorData] = useState("");
  const [updateDateId, setUpdateID] = useState("");
  const [updateInputPlaceholderValue, setUpdateInputPlaceholderValue] =
    useState("");
  const [updateSignInputTitleValue, setUpdateSignInputTitleValue] =
    useState("");
  const [updateInputLabelValue, setUpdateInputLabelValue] = useState("");
  const [isUpdateSignModalOpen, setIsUpdateSignModalOpen] = useState(false);
  const updateClose = (e) => {
    e.preventDefault();
    const updateDateType = e.target?.closest("div").getAttribute("date-type");
    const DateId = e.target?.closest("div").getAttribute("data-id");
    if (updateDateType === "richText") {
      const newInitals = list.find((item) => item.id === DateId);
      setRichTextUpdate(newInitals.text);
      setUpdateTextField(true);
      setUpdateID(DateId);
    } else if (updateDateType === "image") {
      // e.target?.closest("div").querySelectorAll('img')[0];
      setImageUrl(
        e.target?.closest("div").querySelectorAll("img")[0].getAttribute("src")
      );
      setIsUpdateImgModalOpen(true);
      setUpdateID(DateId);
    } else if (updateDateType === "input") {
      const targetinPlaceholder = e.target
        ?.closest("div")
        .querySelectorAll("input")[0]
        .getAttribute("placeholder");
      const targetinlabel = e.target
        ?.closest("div")
        .querySelectorAll("label")[0].textContent;
      setUpdateInputPlaceholderValue(targetinPlaceholder);
      setUpdateInputLabelValue(targetinlabel);
      // inputtype.current.value = e.target?.closest("div").querySelectorAll('input')[0].getAttribute('type')
      setIsUpdateInputModalOpen(true);
      setUpdateID(DateId);
    } else if (updateDateType === "sign") {
      setUpdateID(DateId);
      const targettitle = e.target
        ?.closest("div")
        .querySelectorAll(".signature_col_h")[0].textContent;
      setUpdateSignInputTitleValue(targettitle);
      setIsUpdateSignModalOpen(true);
    }
  };
  const UpdateRichTextValue = (e) => {
    e.preventDefault();
    const updatedItems = list.map((item) => {
      if (item.id === updateDateId) {
        return {
          ...item,
          text: updatedEditorData,
          type: "richText",
          customeStyle: {},
        };
      }
      return item;
    });

    setList(updatedItems);
    setUpdateTextField(false);
  };
  const UpdateImage = (e) => {
    e.preventDefault();
    const buildHtml = `<div style='display: flex; justify-content:${imageAlign.current.value};'><img style='${imageSize.current.value}' src='${imageUrl}'/></div>`;
    const updatedItems = list.map((item) => {
      if (item.id === updateDateId) {
        return { ...item, text: buildHtml };
      }
      return item;
    });
    setList(updatedItems);
    setImageUrl("");
    setIsUpdateImgModalOpen(false);
  };
  const updateinputform = (e) => {
    e.preventDefault();
    let inputHtml = "";
    const inputt = inputtype.current.value;
    if (inputt === "text") {
      inputHtml = `<input type="text" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>'`;
    } else if (inputt === "checkbox") {
      inputHtml = '<input type="checkbox" class=""/>';
    } else if (inputt === "number") {
      inputHtml = `<input type="number" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
    } else if (inputt === "date") {
      inputHtml = `<input type="date" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
    } else if (inputt === "time") {
      inputHtml = `<input type="time" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
    } else if (inputt === "address") {
      inputHtml = `<input type="text" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
    } else {
      inputHtml = `<input type="text" placeholder="${inputPlaceholder.current.value}" class="simpleInput"/>`;
    }
    let completeInput = `<label>${inputLabel.current.value}  ${inputHtml}</label>`;
    if (enabled) {
      completeInput = `<label>${inputLabel.current.value}  ${inputHtml}</label>`;
    } else {
      completeInput = `<label>${inputHtml}  ${inputLabel.current.value}</label>`;
    }
    if (inputalign.current.value !== "Alignment") {
      completeInput = `<div style="text-align:${inputalign.current.value};">${completeInput}</div>`;
    }
    const updatedItems = list.map((item) => {
      if (item.id === updateDateId) {
        return { ...item, text: completeInput };
      }
      return item;
    });
    setList(updatedItems);
    setUpdateInputLabelValue("");
    setUpdateInputPlaceholderValue("");
    setIsUpdateInputModalOpen(false);
  };
  const updateSignFormHandler = (e) => {
    e.preventDefault();
    const buildSignHtml = `
        <div class="signature_col">
            <h4 class="signature_col_h">${updateSignInputTitleValue}</h4>
            <div class="sign__prev">
                <button class="sign__prev_p">Click To Sign</button>
            </div>
            <div class="closeCanva" id="idelWidth" style='display: none;'>
                <canvas class="signatureCanva" width="300px" height="200px"></canvas>
                <button class="close__btn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style='widht: 2.5rem; height: 2.5rem; color: rgb(55 65 81);'>
                        <path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z" clip-rule="evenodd" />
                    </svg>
                </button>
                <button class="clean__btn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style='widht: 2.5rem; height: 2.5rem; color: rgb(239 68 68);'>
                        <path fill-rule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 013.878.512.75.75 0 11-.256 1.478l-.209-.035-1.005 13.07a3 3 0 01-2.991 2.77H8.084a3 3 0 01-2.991-2.77L4.087 6.66l-.209.035a.75.75 0 01-.256-1.478A48.567 48.567 0 017.5 4.705v-.227c0-1.564 1.213-2.9 2.816-2.951a52.662 52.662 0 013.369 0c1.603.051 2.815 1.387 2.815 2.951zm-6.136-1.452a51.196 51.196 0 013.273 0C14.39 3.05 15 3.684 15 4.478v.113a49.488 49.488 0 00-6 0v-.113c0-.794.609-1.428 1.364-1.452zm-.355 5.945a.75.75 0 10-1.5.058l.347 9a.75.75 0 101.499-.058l-.346-9zm5.48.058a.75.75 0 10-1.498-.058l-.347 9a.75.75 0 001.5.058l.345-9z" clip-rule="evenodd" />
                    </svg>
                </button>
                <button class="approve__btn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style='widht: 2.5rem; height: 2.5rem; color: rgb(34 197 94);'>
                        <path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clip-rule="evenodd" />
                    </svg>
                </button>
            </div>
            <img src="" alt="data url" class="showSignature" style='display:none;' />
        </div>
        `;
    const updatedItems = list.map((item) => {
      if (item.id === updateDateId) {
        return { ...item, text: buildSignHtml };
      }
      return item;
    });
    setList(updatedItems);
    setUpdateSignInputTitleValue("");
    setIsUpdateSignModalOpen(false);
  };
  function closeUpdatedTextField() {
    setUpdateTextField(false);
  }
  function UpdateimageModalClose() {
    setIsUpdateImgModalOpen(false);
  }
  function updateinputModalClose() {
    setIsUpdateInputModalOpen(false);
  }
  function updateSignModalClose() {
    setIsUpdateSignModalOpen(false);
  }
  // end here
  // this use effect is signature
  useEffect(() => {
    const signatureCanva = document.querySelectorAll(".signatureCanva");
    const clean__btn = document.querySelectorAll(".clean__btn");
    const approve__btn = document.querySelectorAll(".approve__btn");
    const showSignature = document.querySelectorAll(".showSignature");
    const sign__prev_p = document.querySelectorAll(".sign__prev_p");
    const close__btn = document.querySelectorAll(".close__btn");
    const signaturepad = [];
    for (let i = 0; i < signatureCanva.length; i++) {
      signaturepad[i] = new SignaturePad(signatureCanva[i]);
      let canvasWidth = signatureCanva[i].parentElement.offsetWidth + "px";
      let canvasHeight = signatureCanva[i].parentElement.offsetHeight + "px";
      signatureCanva[i].setAttribute("width", canvasWidth);
      signatureCanva[i].setAttribute("height", canvasHeight);
    }
    // this area is for clean btn
    for (let i = 0; i < clean__btn.length; i++) {
      clean__btn[i].addEventListener("click", function () {
        signaturepad[i].clear();
      });
    }
    // end here
    // this area is for approve btn
    for (let i = 0; i < approve__btn.length; i++) {
      approve__btn[i].addEventListener("click", function () {
        let signatureDateUrl = signaturepad[i].toDataURL();
        showSignature[i].setAttribute("src", signatureDateUrl);
        signatureCanva[i].parentElement.setAttribute("style", "display:none;");
        sign__prev_p[i].parentElement.style.display = "none";
        showSignature[i].setAttribute("style", "display:block");
      });
    }
    for (let i = 0; i < showSignature.length; i++) {
      showSignature[i].addEventListener("click", function () {
        sign__prev_p[i].parentElement.parentElement.querySelectorAll(
          ".closeCanva"
        )[0].style.display = "block";
        const canvasWidth = signatureCanva[i].parentElement.offsetWidth + "px";
        const canvasHeight =
          signatureCanva[i].parentElement.offsetHeight + "px";
        signatureCanva[i].setAttribute("width", canvasWidth);
        signatureCanva[i].setAttribute("height", canvasHeight);
      });
    }
    // end here
    // this area is for close the signature pad
    for (let i = 0; i < close__btn.length; i++) {
      close__btn[i].addEventListener("click", function () {
        sign__prev_p[i].parentElement.parentElement.querySelectorAll(
          ".closeCanva"
        )[0].style.display = "none";
      });
    }
    // end here
    // this area is for set this canvas width when it on
    for (let i = 0; i < sign__prev_p.length; i++) {
      sign__prev_p[i].addEventListener("click", function () {
        sign__prev_p[i].parentElement.parentElement.querySelectorAll(
          ".closeCanva"
        )[0].style.display = "block";
        const canvasWidth = signatureCanva[i].parentElement.offsetWidth + "px";
        const canvasHeight =
          signatureCanva[i].parentElement.offsetHeight + "px";
        signatureCanva[i].setAttribute("width", canvasWidth);
        signatureCanva[i].setAttribute("height", canvasHeight);
      });
    }
    // end here
    // this area and fucntion for updating the widht and height of canvas
    function updateIdel() {
      const signatureCanva = document.querySelectorAll(".signatureCanva");
      for (let i = 0; i < signatureCanva.length; i++) {
        const canvasWidth = signatureCanva[i].parentElement.offsetWidth + "px";
        const canvasHeight =
          signatureCanva[i].parentElement.offsetHeight + "px";
        signatureCanva[i].setAttribute("width", canvasWidth);
        signatureCanva[i].setAttribute("height", canvasHeight);
      }
    }
    window.addEventListener("resize", updateIdel);
    return (_) => {
      window.removeEventListener("resize", updateIdel);
    };
    // end here
  }, [list]);
  const isScript = `
    <script>
        const signatureCanva = document.querySelectorAll(".signatureCanva");
        const clean__btn = document.querySelectorAll('.clean__btn')
        const approve__btn = document.querySelectorAll('.approve__btn');
        const showSignature = document.querySelectorAll('.showSignature');
        const sign__prev_p = document.querySelectorAll('.sign__prev_p');
        const close__btn = document.querySelectorAll('.close__btn');
        const signaturepad = [];
        for (let i = 0; i < signatureCanva.length; i++) {
            signaturepad[i] = new SignaturePad(signatureCanva[i])
            let canvasWidth = signatureCanva[i].parentElement.offsetWidth + 'px';
            let canvasHeight = signatureCanva[i].parentElement.offsetHeight + 'px';
            signatureCanva[i].setAttribute('width', canvasWidth)
            signatureCanva[i].setAttribute('height', canvasHeight)   
        }
        // this area is for clean btn  
        for(let i=0; i<clean__btn.length; i++){
            console.log(signaturepad[i])
            clean__btn[i].addEventListener('click', function (){
                signaturepad[i].clear();
            })
        }
        // end here 
        // this area is for approve btn 
        for(let i=0; i<approve__btn.length; i++){
            approve__btn[i].addEventListener('click', function(){
                let signatureDateUrl = signaturepad[i].toDataURL()
                showSignature[i].setAttribute('src', signatureDateUrl);
                signatureCanva[i].parentElement.setAttribute('style', 'display:none;');
                sign__prev_p[i].parentElement.style.display = 'none';
                showSignature[i].setAttribute('style', 'display:block');
            })
        }
        for(let i=0; i<showSignature.length; i++){
            showSignature[i].addEventListener('click', function(){
            sign__prev_p[i].parentElement.parentElement.querySelectorAll('.closeCanva')[0].style.display = 'block';
            const canvasWidth = signatureCanva[i].parentElement.offsetWidth + "px";
            const canvasHeight = signatureCanva[i].parentElement.offsetHeight + "px";
            signatureCanva[i].setAttribute('width', canvasWidth);
            signatureCanva[i].setAttribute('height', canvasHeight);
            })
        } 
        // end here 
        // this area is for close the signature pad 
        for(let i=0; i<close__btn.length; i++){
            close__btn[i].addEventListener('click', function(){
                sign__prev_p[i].parentElement.parentElement.querySelectorAll('.closeCanva')[0].style.display = 'none'
            })
        }
        // end here 
        // this area is for set this canvas width when it on 
        for(let i =0; i<sign__prev_p.length; i++){
            sign__prev_p[i].addEventListener('click', function(){
                sign__prev_p[i].parentElement.parentElement.querySelectorAll('.closeCanva')[0].style.display = 'block'
                const canvasWidth = signatureCanva[i].parentElement.offsetWidth + "px";
                const canvasHeight = signatureCanva[i].parentElement.offsetHeight + "px";
                signatureCanva[i].setAttribute('width', canvasWidth);
                signatureCanva[i].setAttribute('height', canvasHeight);
            })
        }
        // end here 
        // this area and fucntion for updating the widht and height of canvas 
        function updateIdel() {
            const signatureCanva = document.querySelectorAll(".signatureCanva");
            for (let i = 0; i < signatureCanva.length; i++) {
                const canvasWidth = signatureCanva[i].parentElement.offsetWidth + "px";
                const canvasHeight = signatureCanva[i].parentElement.offsetHeight + "px";
                signatureCanva[i].setAttribute('width', canvasWidth);
                signatureCanva[i].setAttribute('height', canvasHeight);
            }
        }
        window.addEventListener('resize', updateIdel);
    </script>
    `;
  // this area is for update content when user use contentEditable 
  const [userEditedContent, setUserEditedContent] = useState('')
  const [userEditedContentId, setUserEditedContentId] = useState('')
  const updateEditedContent = (e) => {
    e.preventDefault();
    const editedContent = e.target?.innerHTML;
    const editedContentId = e.target?.closest("div").parentElement.getAttribute('data-id');
    setUserEditedContent(editedContent);
    setUserEditedContentId(editedContentId);
    // console.log(editedContent + editedContentId);
  }
  const finishEditing = (e) => {
    e.preventDefault();
    const updatedItems = list.map((item) => {
      if (item.id === userEditedContentId) {
        return { ...item, text: userEditedContent };
      }
      return item;
    });
    setList(updatedItems);
  }
  // end here 
  return (
    <>
      <div className="flex">
        <MainSidebar
          textLInk={textFieldOpen}
          inputLink={inputModalOpen}
          signLink={signModalOpen}
          imgLInk={imgFieldOpen}
          layoutLink={layoutSectionOpen}
          downloadLink={downloadLink}
          exportHtml={handleClick}
        />
        <div className="main_div p-4 w-full">
          <style>{HTMLstyle}</style>
          {list.map((item, index) => (
            <div
              key={index}
              data-position={index}
              draggable
              id={index}
              onDragStart={onDragStart}
              onDragOver={onDragOver}
              onDrop={onDrop}
              onDragExit={onDragLeave}
              className="w-full"
            >
              {/* {console.log(item.customeStyle)} */}
              <div
                className="relative w-full close_remove update"
                data-id={item.id}
                date-type={item.type}
              >
                <div
                  className="select-text"
                  contentEditable="true"
                  onInput={updateEditedContent}
                  onBlur={finishEditing}
                  style={item.customeStyle}
                  dangerouslySetInnerHTML={{ __html: item.text }}
                />
                <button
                  title="Remove Item"
                  onClick={removerClose}
                  className="bg-transparent absolute top-[50%] right-24 shadow-md border-none cursor-pointer p-2 no_no"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-6 h-6 text-red-600"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
                    />
                  </svg>
                </button>
                <button
                  onClick={updateClose}
                  title="Update Item"
                  className="bg-transparent absolute top-[50%] right-12 shadow-md border-none cursor-pointer p-2 no_no"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-6 h-6 text-green-600"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125"
                    />
                  </svg>
                </button>
                <button
                  onClick={deisgnClose}
                  title="Change Styling"
                  className="bg-transparent absolute top-[50%] right-0 shadow-md border-none cursor-pointer p-2 no_no"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-6 h-6 text-purple-600"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M15 11.25l1.5 1.5.75-.75V8.758l2.276-.61a3 3 0 10-3.675-3.675l-.61 2.277H12l-.75.75 1.5 1.5M15 11.25l-8.47 8.47c-.34.34-.8.53-1.28.53s-.94.19-1.28.53l-.97.97-.75-.75.97-.97c.34-.34.53-.8.53-1.28s.19-.94.53-1.28L12.75 9M15 11.25L12.75 9"
                    />
                  </svg>
                </button>
              </div>
            </div>
          ))}
          {/* <div className="w-[400px] h-[400px] bg-blue-200 dragIntoDiv"
            onDrop={drop_handler}
            onDragOver={dragover_handler}
          >
          </div> */}
        </div>
        <div className="hidden" ref={containerRef}>
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/@heroicons/css@latest/dist/heroicons.css"
          />
          <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/@heroicons/css@latest/dist/heroicons.min.css"
          />
          <style>{HTMLstyle}</style>
          <main class="container">
            {list.map((item, index) => {
              return (
                <div
                  style={item.customeStyle}
                  key={index}
                  dangerouslySetInnerHTML={{ __html: item.text }}
                />
              );
            })}
            <script src="https://cdn.jsdelivr.net/npm/signature_pad@3.0.0-beta.3/dist/signature_pad.umd.min.js"></script>
            <div dangerouslySetInnerHTML={{ __html: isScript }}></div>
          </main>
        </div>
      </div>
      {/* this area is for TextField Modal  */}
      <Modal title="Import Text" show={isTextFieldOpen} close={closeModal}>
        <form action="#" onSubmit={submitTextValue}>
          <div className="mt-2">
            <EditorComp editorContent={setEditorData} initialValue="" />
          </div>
          <div className="mt-4">
            <button
              type="submit"
              className="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
            >
              submit
            </button>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      {/* this area is for TextField Modal update  */}
      <Modal
        title="Update Text"
        show={updateTextField}
        close={closeUpdatedTextField}
      >
        <form action="#" onSubmit={UpdateRichTextValue}>
          <div className="mt-2">
            <EditorComp
              editorContent={setUpdatedEditorData}
              initialValue={richTextUpdate}
            />
          </div>
          <div className="mt-4">
            <button
              type="submit"
              className="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
            >
              submit
            </button>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      {/* this area is for image field modal  */}
      <Modal
        title="Import Images"
        show={isImgModalOpen}
        close={imageModalClose}
      >
        <form action="" onSubmit={AddImageToList}>
          <div className="flex gap-4 items-start mt-4">
            <div className="basis-1/2">
              <div className="mb-3">
                <label className="flex justify-center items-center p-2 bg-blue-100 rounded-lg shadow-lg tracking-wide uppercase cursor-pointer hover:bg-blue-200 ">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-6 h-6 text-blue-900 mr-3"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"
                    />
                  </svg>
                  <span className="text-blue-900">Select a file</span>
                  <input
                    type="file"
                    className="hidden"
                    // onChange={ImageFieldUload}
                    onChange={e => convertToBase64(e.target.files[0])}
                  />
                </label>
              </div>
              <div className="mb-3">
                <select
                  ref={imageAlign}
                  class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                >
                  <option selected disabled>
                    Alignment
                  </option>
                  <option value="flex-start">Left</option>
                  <option value="flex-end">Right</option>
                  <option value="center">Center</option>
                </select>
              </div>
              <div className="mb-3">
                <select
                  ref={imageSize}
                  class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                >
                  <option selected disabled>
                    Size
                  </option>
                  <option value="width: 50px;">Small</option>
                  <option value="width: 150px;">Medium</option>
                  <option value="width: 50%; max-width: 400px">Large</option>
                  <option value="width: 80%; max-width: 600px">
                    ExtraLarge
                  </option>
                  <option value="width: 100%;">full</option>
                </select>
              </div>
              <div className="mb-3">
                <button
                  type="submit"
                  className="inline-flex justify-center rounded-md border border-transparent cursor-pointer bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                >
                  submit
                </button>
              </div>
            </div>
            <div className="basis-1/2">
              <img src={imageUrl} alt="" className="w-full" />
            </div>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      {/* this area is for image edit  */}
      <Modal
        title="Update Images"
        show={isUpdateImgModalOpen}
        close={UpdateimageModalClose}
      >
        <form action="" onSubmit={UpdateImage}>
          <div className="flex gap-4 items-start mt-4">
            <div className="basis-1/2">
              <div className="mb-3">
                <label className="flex justify-center items-center p-2 bg-blue-100 rounded-lg shadow-lg tracking-wide uppercase cursor-pointer hover:bg-blue-200 ">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-6 h-6 text-blue-900 mr-3"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"
                    />
                  </svg>
                  <span className="text-blue-900">Select a file</span>
                  <input
                    type="file"
                    className="hidden"
                    // onChange={ImageFieldUload}
                    onChange={e => convertToBase64(e.target.files[0])}
                  />
                </label>
              </div>
              <div className="mb-3">
                <select
                  ref={imageAlign}
                  class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                >
                  <option selected disabled>
                    Alignment
                  </option>
                  <option value="flex-start">Left</option>
                  <option value="flex-end">Right</option>
                  <option value="center">Center</option>
                </select>
              </div>
              <div className="mb-3">
                <select
                  ref={imageSize}
                  class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                >
                  <option selected disabled>
                    Size
                  </option>
                  <option value="width: 50px;">Small</option>
                  <option value="width: 150px;">Medium</option>
                  <option value="width: 50%; max-width: 400px">Large</option>
                  <option value="width: 80%; max-width: 600px">
                    ExtraLarge
                  </option>
                  <option value="width: 100%;">full</option>
                </select>
              </div>
              <div className="mb-3">
                <button
                  type="submit"
                  className="inline-flex justify-center rounded-md border border-transparent cursor-pointer bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                >
                  submit
                </button>
              </div>
            </div>
            <div className="basis-1/2">
              <img src={imageUrl} alt="" className="w-full" />
            </div>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      {/* this area is for input field modal  */}
      <Modal
        title="Import Input"
        show={isInputModalOpen}
        close={inputModalClose}
      >
        <form action="" onSubmit={inputFormHandler}>
          <div className="flex gap-4 items-start mt-4">
            <div className="basis-full">
              <div className="mb-3">
                <select
                  ref={inputtype}
                  class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                >
                  <option selected disabled>
                    Input Type
                  </option>
                  <option value="text">text</option>
                  <option value="checkbox">checkbox</option>
                  <option value="number">number</option>
                  <option value="date">date</option>
                  <option value="time">time</option>
                  <option value="address">address</option>
                </select>
              </div>

              <div
                className="mb-3"
                style={{ display: `${inputCheck ? "block" : "none"}` }}
              >
                <input
                  ref={inputPlaceholder}
                  type="text"
                  placeholder="Enter Placeholder"
                  className="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                />
              </div>
              <div
                className="mb-3"
                style={{ display: `${inputCheck ? "block" : "none"}` }}
              >
                <input
                  ref={inputLabel}
                  type="text"
                  placeholder="Enter label"
                  className="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                />
              </div>
              <div
                className="mb-3"
                style={{ display: `${inputCheck ? "block" : "none"}` }}
              >
                <select
                  ref={inputalign}
                  class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                >
                  <option selected disabled>
                    Alignment
                  </option>
                  <option value="left">Left</option>
                  <option value="center">Center</option>
                  <option value="right">Right</option>
                </select>
              </div>
              <div
                className="mb-3 text-gray-500 font-sans"
                style={{ display: `${inputCheck ? "block" : "none"}` }}
              >
                <p className="mb-3">Input Place At</p>
                <p className="flex items-center">
                  Strart{" "}
                  <Switch
                    checked={enabled}
                    onChange={setEnabled}
                    className={`${enabled ? "bg-teal-900" : "bg-teal-700"} 
                                    relative inline-flex h-[28px] w-[54px] shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus-visible:ring-2  focus-visible:ring-white focus-visible:ring-opacity-75 mx-4`}
                  >
                    <span className="sr-only">Use setting</span>
                    <span
                      aria-hidden="true"
                      className={`pointer-events-none inline-block h-[24px] w-[24px] transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out`}
                      style={{
                        transform: enabled
                          ? "translateX(26px)"
                          : "translateX(0px)",
                      }}
                    />
                  </Switch>{" "}
                  End
                </p>
              </div>
              <div className="mb-3">
                <button
                  type="submit"
                  className="inline-flex justify-center rounded-md border border-transparent cursor-pointer bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                >
                  submit
                </button>
              </div>
            </div>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      {/* this area is for input field update  */}
      <Modal
        title="Import Input"
        show={isUpdateInputModalOpen}
        close={updateinputModalClose}
      >
        <form action="" onSubmit={updateinputform}>
          <div className="flex gap-4 items-start mt-4">
            <div className="basis-full">
              <div className="mb-3">
                <select
                  ref={inputtype}
                  id="inputtype"
                  class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                >
                  <option selected disabled>
                    Input Type
                  </option>
                  <option value="text">text</option>
                  <option value="checkbox">checkbox</option>
                  <option value="number">number</option>
                  <option value="date">date</option>
                  <option value="time">time</option>
                  <option value="address">address</option>
                </select>
              </div>

              <div className="mb-3">
                <input
                  ref={inputPlaceholder}
                  value={updateInputPlaceholderValue}
                  onChange={(e) => {
                    setUpdateInputPlaceholderValue(e.target.value);
                  }}
                  type="text"
                  placeholder="Enter Placeholder"
                  className="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                />
              </div>
              <div className="mb-3">
                <input
                  ref={inputLabel}
                  value={updateInputLabelValue}
                  onChange={(e) => {
                    setUpdateInputLabelValue(e.target.value);
                  }}
                  type="text"
                  placeholder="Enter label"
                  className="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                />
              </div>
              <div className="mb-3">
                <select
                  ref={inputalign}
                  class="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                >
                  <option selected disabled>
                    Alignment
                  </option>
                  <option value="left">Left</option>
                  <option value="center">Center</option>
                  <option value="right">Right</option>
                </select>
              </div>
              <div className="mb-3 text-gray-500 font-sans">
                <p className="mb-3">Input Place At</p>
                <p className="flex items-center">
                  Strart{" "}
                  <Switch
                    checked={enabled}
                    onChange={setEnabled}
                    className={`${enabled ? "bg-teal-900" : "bg-teal-700"} 
                                    relative inline-flex h-[28px] w-[54px] shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus-visible:ring-2  focus-visible:ring-white focus-visible:ring-opacity-75 mx-4`}
                  >
                    <span className="sr-only">Use setting</span>
                    <span
                      aria-hidden="true"
                      className={`pointer-events-none inline-block h-[24px] w-[24px] transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out`}
                      style={{
                        transform: enabled
                          ? "translateX(26px)"
                          : "translateX(0px)",
                      }}
                    />
                  </Switch>{" "}
                  End
                </p>
              </div>
              <div className="mb-3">
                <button
                  type="submit"
                  className="inline-flex justify-center rounded-md border border-transparent cursor-pointer bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                >
                  submit
                </button>
              </div>
            </div>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      {/* this area is for signature input field  */}
      <Modal
        title="Import Signature"
        show={isSignModalOpen}
        close={signModalClose}
      >
        <form onSubmit={signFormHandler}>
          <div className="flex gap-4 items-start mt-4">
            <div className="basis-full">
              <div className="mb-3">
                <input
                  ref={signInputTitle}
                  type="text"
                  placeholder="Enter Signature Title"
                  className="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                />
              </div>
              <div className="mb-3">
                <button
                  type="submit"
                  className="inline-flex justify-center rounded-md border border-transparent cursor-pointer bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                >
                  submit
                </button>
              </div>
            </div>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      {/* this area is for signature input field  */}
      <Modal
        title="Import Signature"
        show={isUpdateSignModalOpen}
        close={updateSignModalClose}
      >
        <form onSubmit={updateSignFormHandler}>
          <div className="flex gap-4 items-start mt-4">
            <div className="basis-full">
              <div className="mb-3">
                <input
                  ref={signInputTitle}
                  type="text"
                  value={updateSignInputTitleValue}
                  onChange={(e) => {
                    setUpdateSignInputTitleValue(e.target.value);
                  }}
                  placeholder="Enter Signature Title"
                  className="block py-2.5 px-0 w-full text-sm text-gray-500 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
                />
              </div>
              <div className="mb-3">
                <button
                  type="submit"
                  className="inline-flex justify-center rounded-md border border-transparent cursor-pointer bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                >
                  submit
                </button>
              </div>
            </div>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      {/* this modal for styling  */}
      <Modal
        title="UpDate Styles"
        show={isStyleModalOpen}
        close={styleModalClose}
      >
        <form onSubmit={styleHandler}>
          <div className="grid grid-cols-4 gap-8 items-start mt-4">
            <div className="col-span-1">
              <span>margin Top</span>
              <ReactSlider
                step={1}
                min={0}
                max={100}
                className="w-full h-3 pr-2 my-4 bg-gray-200 rounded-md cursor-grab"
                thumbClassName="absolute w-5 h-5 cursor-grab bg-indigo-500 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 top-[-4px]"
                value={topMarginValue}
                onChange={(value) => {
                  setTopMarginValue(value);
                }}
              />
              <span>{topMarginValue} px</span>
            </div>
            <div className="col-span-1">
              <span>margin right</span>
              <ReactSlider
                step={1}
                min={0}
                max={100}
                className="w-full h-3 pr-2 my-4 bg-gray-200 rounded-md cursor-grab"
                thumbClassName="absolute w-5 h-5 cursor-grab bg-indigo-500 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 top-[-4px]"
                value={rightMarginValue}
                onChange={(value) => {
                  setRightMarginValue(value);
                }}
              />
              <span>{rightMarginValue} px</span>
            </div>
            <div className="col-span-1">
              <span>margin bottom</span>
              <ReactSlider
                step={1}
                min={0}
                max={100}
                className="w-full h-3 pr-2 my-4 bg-gray-200 rounded-md cursor-grab"
                thumbClassName="absolute w-5 h-5 cursor-grab bg-indigo-500 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 top-[-4px]"
                value={bottomMarginValue}
                onChange={(value) => {
                  setBottomMarginValue(value);
                }}
              />
              <span>{bottomMarginValue} px</span>
            </div>
            <div className="col-span-1">
              <span>margin left</span>
              <ReactSlider
                step={1}
                min={0}
                max={100}
                className="w-full h-3 pr-2 my-4 bg-gray-200 rounded-md cursor-grab"
                thumbClassName="absolute w-5 h-5 cursor-grab bg-indigo-500 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 top-[-4px]"
                value={leftMarginValue}
                onChange={(value) => {
                  setLeftMarginValue(value);
                }}
              />
              <span>{leftMarginValue} px</span>
            </div>
          </div>
          <div className="mb-3">
            <button
              type="submit"
              className="inline-flex justify-center rounded-md border border-transparent cursor-pointer bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
            >
              submit
            </button>
          </div>
        </form>
      </Modal>
      {/* end here  */}
      <Modal title="Import Text" show={islayoutModalOpen} close={closeLayoutModal} >
        <div className="form">
          <div className="div mt-2">
            <div className="">
              <RadioGroup value={selected} onChange={setSelected}>
                <RadioGroup.Label className="sr-only">Server size</RadioGroup.Label>
                <div className="space-y-2">
                  {plans.map((plan) => (
                    <RadioGroup.Option
                      key={plan.name}
                      value={plan}
                      className={({ active, checked }) =>
                        `${active
                          ? 'ring-2 ring-white ring-opacity-60 ring-offset-2 ring-offset-sky-300'
                          : ''
                        }
                  ${checked ? 'bg-sky-900 bg-opacity-75 text-white' : 'bg-white'
                        }
                    relative flex cursor-pointer rounded-lg px-5 py-4 shadow-md focus:outline-none`
                      }
                    >
                      {({ active, checked }) => (
                        <>
                          <div className="flex w-full items-center justify-between">
                            <div className="flex items-center">
                              <div className="text-sm">
                                <RadioGroup.Label
                                  as="p"
                                  className={`font-medium  ${checked ? 'text-white' : 'text-gray-900'
                                    }`}
                                >
                                  {plan.name}
                                </RadioGroup.Label>
                                <RadioGroup.Description
                                  as="span"
                                  className={`inline ${checked ? 'text-sky-100' : 'text-gray-500'
                                    }`}
                                >
                                  <span>
                                    {plan.ram}/{plan.cpus}
                                  </span>{' '}
                                  <span aria-hidden="true">&middot;</span>{' '}
                                  <span>{plan.disk}</span>
                                </RadioGroup.Description>
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </RadioGroup.Option>
                  ))}
                </div>
              </RadioGroup>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
}
