import React, {useRef} from 'react'

const DownloadHTML = () => {
    const containerRef = useRef(null);
    const HTMLstyle = `*{
        margin: 0px;
        padding: 0px;
    }`;
    const [downloadLink, setDownloadLink] = useState("")
    const handleClick = () => {
        const html = containerRef.current.innerHTML;
        const blob = new File([html], 'export.html', { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        setDownloadLink(url)
    };
}

export default DownloadHTML