import React from 'react'
import NoCodeHome from './components/NoCodeHome'

const App = () => {
  return (
    <>
     <NoCodeHome />
    </>
  )
}

export default App