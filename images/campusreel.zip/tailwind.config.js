/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primaryBlack: "#000",
        primaryYellow: "#FEC846",
        primaryGreen: "#64C67E",
        primaryBlue: "#95CCFF",
        primaryVoilet: "#B76FEF",
      },
      fontFamily:{
        heading: "'Redressed', cursive"
      },
      screens: {
        sm: '550px',
      },
      container: {
        padding: '1rem',
      },
    },
  },
  plugins: [],
}
