import React from 'react'
const StatusCard = (props) => {
  return (
    <a href="#" className="group relative block bg-black h-[450px] rounded-lg" style={{background : `linear-gradient(transparent,rgba(0,0,0,0.2) 50%,rgba(0,0,0,0.7)), url(${props.bgUrl})no-repeat center center/cover`}}>
        <div className="absolute bottom-0 p-8">
            <p className="text-xl font-bold tracking-widest text-white">
            {props.title}
            </p>
            <p className="text-md font-light text-white">{props.detail}</p>
        </div>
    </a>
  )
}

export default StatusCard
