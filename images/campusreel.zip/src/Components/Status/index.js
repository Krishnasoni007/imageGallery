import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import {Navigation } from "swiper";
import StatusCard from "./StatusCard";
const statusData = [
    {bgUrl: 'https://images.unsplash.com/photo-1669872666457-d5a771c83715?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80', title: 'lorem ipsume', detail: 'lorem ipsume dolor?'},
    {bgUrl: 'https://images.unsplash.com/photo-1669837401587-f9a4cfe3126e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80', title: 'lorem ipsume', detail: 'lorem ipsume dolor?'},
    {bgUrl: 'https://images.unsplash.com/photo-1669846510648-95ffffb8e269?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880&q=80', title: 'lorem ipsume', detail: 'lorem ipsume dolor?'},
    {bgUrl: 'https://images.unsplash.com/photo-1657299143437-b63ce1fc01aa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80', title: 'lorem ipsume', detail: 'lorem ipsume dolor?'},
    {bgUrl: 'https://images.unsplash.com/photo-1657299143020-4f4bbf05174d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1167&q=80', title: 'lorem ipsume', detail: 'lorem ipsume dolor?'},
]
export default function Status() {
    
  return (
      <section className="p-4 mt-4">
        <Swiper
        slidesPerView={4}
        spaceBetween={30}
        slidesPerGroup={1}
        loop={true}
        breakpoints={{
            1536: {
              slidesPerView: 4,
            },
            1280: {
              slidesPerView: 3,
            },
            768: {
              slidesPerView: 2,
            },
            500: {
              slidesPerView: 1,
            },
          }}
        loopFillGroupWithBlank={true}
        pagination={{
        clickable: true,
        }}
        navigation={true}
        autoplay={{
            delay: 2500,
            disableOnInteraction: false,
        }}
        modules={[Navigation]}
        className="mySwiper"
            
        >
            {statusData.map((status, ind) =>{
            return(
                <SwiperSlide key={ind}>
                    <StatusCard title={status.title} detail={status.detail} bgUrl={status.bgUrl} />
                </SwiperSlide>
            )
            })}
        </Swiper>
      </section>
  )
}

