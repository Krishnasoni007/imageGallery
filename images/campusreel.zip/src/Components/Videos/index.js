import React from 'react'
import VideoCard from './VideoCard'
import LightGallery from 'lightgallery/react';

// import styles
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lg-zoom.css';
import 'lightgallery/css/lg-video.css';

// import plugins if you need
import lgVideo from 'lightgallery/plugins/video';
import lgZoom from 'lightgallery/plugins/zoom';

const videoData = [
  { url: "https://images.pexels.com/videos/6988742/fisheye-gen-z-generation-z-girls-6988742.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/489779797?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14594516/2022-aerial-aerial-tramway-aerial-video-14594516.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/776168876?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14507172/a-life-aerial-shot-aerial-tramway-arch-architectural-feature-14507172.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/773130100?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14545576/blue-food-foodlover-foodporn-14545576.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/774758540?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/6988742/fisheye-gen-z-generation-z-girls-6988742.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/489779797?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14594516/2022-aerial-aerial-tramway-aerial-video-14594516.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/776168876?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14507172/a-life-aerial-shot-aerial-tramway-arch-architectural-feature-14507172.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/773130100?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14545576/blue-food-foodlover-foodporn-14545576.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/774758540?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/6988742/fisheye-gen-z-generation-z-girls-6988742.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/489779797?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14594516/2022-aerial-aerial-tramway-aerial-video-14594516.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/776168876?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14507172/a-life-aerial-shot-aerial-tramway-arch-architectural-feature-14507172.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/773130100?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14545576/blue-food-foodlover-foodporn-14545576.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/774758540?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/6988742/fisheye-gen-z-generation-z-girls-6988742.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/489779797?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14594516/2022-aerial-aerial-tramway-aerial-video-14594516.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/776168876?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14507172/a-life-aerial-shot-aerial-tramway-arch-architectural-feature-14507172.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/773130100?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
  { url: "https://images.pexels.com/videos/14545576/blue-food-foodlover-foodporn-14545576.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load", 
    title: "lorem ipsume", 
    des: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. At voluptatibus enim, recusandae nihil officia vitae cupiditate! Nemo quaerat exercitationem praesentium.", 
    likes: '334', 
    location: 'Santa Cruz, CA', 
    src: "//player.vimeo.com/video/774758540?title=0&portrait=0&byline=0&autoplay=1&muted=true",
  },
]
const index = () => {
  const onInit = () => {
      console.log('lightGallery has been initialized');
  };
  return (
    <section className='video-section mt-4 p-4'>
      <LightGallery
                onInit={onInit}
                speed={500}
                plugins={[lgVideo, lgZoom]}
                addClass=""
            >
    {videoData.map((video, index) =>{
        return(
            <VideoCard src={video.src} key={index} url={video.url} title={video.title} des={video.des} location={video.location} likes={video.likes} />
        )
    })}
    </LightGallery>
    </section>
  )
}

export default index
