import React from 'react'
const VideoCard = (props) => {
  return (
    <a data-src={props.src} className="video-card block bg-white rounded-xl shadow-md shadow-slate-300 hover:shadow-lg overflow-hidden">
        <div className="card-details m-4">
            <img src={props.url} alt="" className='rounded-md'/>
            <h4 className='text-2xl text-black my-3'>{props.title}</h4>
            <p className='text-md text-gray-500 mb-3'>{props.des}</p>
            <button className='py-1 px-1 rounded-sm border-b-[1px] border-black'>Click</button>
        </div>
        <div className="card-footer border-t-2 flex justify-between px-4 py-2 bg-[rgba(0,0,0,.03)]">
            <div className="left text-xs">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 inline text-peach mr-3">
                <path fillRule="evenodd" d="M11.54 22.351l.07.04.028.016a.76.76 0 00.723 0l.028-.015.071-.041a16.975 16.975 0 001.144-.742 19.58 19.58 0 002.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 00-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 002.682 2.282 16.975 16.975 0 001.145.742zM12 13.5a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
            </svg>{props.location}</div>
            <div className="right text-xs">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 inline text-peach mr-3">
                <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
            </svg>{props.likes}</div>
        </div>
    </a>
  )
}

export default VideoCard
