import React from 'react'
import {TbBrandFacebook} from 'react-icons/tb'
import {RiTwitterLine} from 'react-icons/ri'
import {SiInstagram} from 'react-icons/si'
import {FiYoutube} from 'react-icons/fi'
const Footer = () => {
    return (
        <footer className='mt-20 mb-10'>
            <div className="container mx-auto">
                <div className="grid grid-cols-12 gap-6 place-content-stretch">
                    <div className='col-span-3 gray_bg p-6 rounded-xl'>
                        <img src={require("../../images/white-logo.png")} alt="" className='mb-6' />
                        <button className='brand-btn white mb-6'><span>Schedule demo</span></button>
                        <div className="mb-6">
                            <h3 className='font-heading text-4xl mb-4 text-white'>Tools for Students</h3>
                            <ul className='list-disc'>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">California Scholarships</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Chances Calculator</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Guide to Transferring</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">High School GPA Calculator</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">MBA Chances Calculator</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Student Jobs</a></li>
                            </ul>
                        </div>
                    </div>
                    <div className='col-span-4 gray_bg p-6 rounded-xl'>
                        <div className="mb-6">
                            <h3 className='font-heading text-4xl mb-4 text-white'>Higher Education Recruitment</h3>
                            <ul className='list-disc'>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Enrollment & Recruitment Video Solutions</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">For Colleges & Universities</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">For Community Colleges</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">For Business Schools & MBA Programs</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">For Graduate Programs</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Student Recruitment Playbook</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Partner Login</a></li>
                            </ul>
                        </div>
                        <div className="mb-6">
                            <h3 className='font-heading text-4xl mb-4 text-white'>Partnerships</h3>
                            <ul className='list-disc'>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">For Colleges</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">For High Schools</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Integrations</a></li>
                                <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Administrator Login</a></li>
                            </ul>
                        </div>
                    </div>
                    <div className='col-span-5 grid gap-6 grid-flow-row'>
                        <div className='gray_bg p-6 rounded-xl'>
                            <div className="mb-6">
                                <h3 className='font-heading text-4xl mb-4 text-white'>Partnerships</h3>
                                <ul className='list-disc'>
                                    <li className='text-white mb-2 ml-4'><a className='text-white' href="#">For Colleges</a></li>
                                    <li className='text-white mb-2 ml-4'><a className='text-white' href="#">For High Schools</a></li>
                                    <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Integrations</a></li>
                                    <li className='text-white mb-2 ml-4'><a className='text-white' href="#">Administrator Login</a></li>
                                </ul>
                            </div>
                            <button className='brand-btn white mb-6'><span>Schedule demo</span></button>
                        </div>
                        <div className='gray_bg p-6 rounded-xl place-self-stretch'>
                            <div className="mb-6">
                                <h3 className='font-heading text-4xl mb-4 text-white'>Follow Us at</h3>
                                <div className="mb-6 flex items-center gap-6">
                                    <a href='#' className='w-[45px] h-[45px] flex items-center justify-center border-2 border-white rounded-full'><TbBrandFacebook className='text-white' /></a>
                                    <a href='#' className='w-[45px] h-[45px] flex items-center justify-center border-2 border-white rounded-full'><RiTwitterLine className='text-white' /></a>
                                    <a href='#' className='w-[45px] h-[45px] flex items-center justify-center border-2 border-white rounded-full'><SiInstagram className='text-white' /></a>
                                    <a href='#' className='w-[45px] h-[45px] flex items-center justify-center border-2 border-white rounded-full'><FiYoutube className='text-white' /></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    )
}

export default Footer
