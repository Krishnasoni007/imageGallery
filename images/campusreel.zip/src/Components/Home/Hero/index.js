import React from 'react'
import { BsPlayCircle, BsArrowUpRight } from 'react-icons/bs'
import { motion } from 'framer-motion'
const Hero = () => {
    return (
        <section className="hero">
            <div className="container mx-auto relative flex items-center mt-20">
                <div>
                    <motion.div className="mb-14 opacity-50" animate={{scale: 0.8,opacity: 1 , transition: {duration: .6}}}>
                        <h1 className="flex items-center relative justify-center mb-2 sm:mb-4 font-heading text-3xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl">
                            Welcome <span><img src={require('../../../images/yellowround.png')} alt="" className='w-10 md:w-16 lg:w-22 xl:w-28 mx-2' /></span> CampusReel
                            <span><img src={require("../../../images/curve__arrow.png")} alt="" className='absolute hidden xl:block xl:top-16 xl:right-16 xl:w-56 2xl:top-16 2xl:right-36' /></span>
                        </h1>
                        <p className='text-center text-gray-600 font-medium text-[10px] sm:text-[16px] lg:text-[26px]'>
                            Universities and programs come alive on CampusReel.
                        </p>
                        <p className='flex justify-center items-center text-gray-600 font-medium text-[10px] sm:text-[16px] lg:text-[26px]'>We build our communities <span><img src={require('../../../images/comunity.png')} alt="" className='w-10 md:w-20' /></span> through video.</p>
                    </motion.div>
                    <div className='grid grid-flow-col grid-rows-2 grid-cols-12 gap-6'>
                        <div className="left row-span-1 col-start-1 col-end-6 rounded-full shadow-xl bg-white p-6">
                            <a href="#" className="flex items-center justify-center h-full gap-0 ">
                                <BsArrowUpRight className='text-white text-6xl bg-primaryGreen p-4 flex items-center justify-center w-1/4 mr-4 h-auto rounded-full' />
                                <div className='w-3/4'>
                                    <h3 className='font-heading text-4xl mb-1 text-primaryBlack opacity-70'>For Higher Education</h3>
                                    <p className='text-md font-medium text-primaryBlack opacity-50 '>Create & Scale Video Content that Drives Recruitment and Enrollment Outcomes.</p>
                                </div>
                            </a>
                        </div>
                        <div className="left row-span-1 col-start-1 col-end-6 rounded-full shadow-xl bg-white p-6">
                            <a href="#" className="flex items-center justify-center h-full gap-0 ">
                                <BsArrowUpRight className='text-white text-6xl bg-primaryBlue p-4 flex items-center justify-center w-1/4 mr-4 h-auto rounded-full' />
                                <div className='w-3/4'>
                                    <h3 className='font-heading text-4xl mb-1 text-primaryBlack opacity-70'>For Students & Families</h3>
                                    <p className='text-md font-medium text-primaryBlack opacity-50 '>Find Your Best Fit University or Program with 15,000+ videos.</p>
                                </div>
                            </a>
                        </div>
                        <div className='right col-start-7 col-end-13 row-span-2'>
                            <div className="video relative">
                                <video className='w-full h-full rounded-2xl' poster={require('../../../images/heroimg.jfif')}>
                                    <source src={require("../../../images/herovideo.mp4")} type="video/mp4" />
                                </video>
                                <button className='absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] cursor-pointer'><BsPlayCircle className='text-white text-6xl' /></button>
                                <img src={require('../../../images/heroicon1.png')} alt="" className='absolute top-[10%] left-[-15%]' />
                                <img src={require('../../../images/heroicon2.png')} alt="" className='absolute top-[25%] right-[-10%]' />
                                <img src={require('../../../images/heroicon3.png')} alt="" className='absolute bottom-[25%] left-[-10%]' />
                                <img src={require('../../../images/heroicon4.png')} alt="" className='absolute bottom-[-5%] right-[20%]' />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Hero
