import React, {useRef, useState, useEffect} from 'react'
import { useTransform, useScroll, motion, useInView } from 'framer-motion'
import arrowsvg from '../../images/circle-arrow.svg'
const RecommededBy = () => {
    const [widthvalue, setWidhtvalue] = useState(null)
    const [Scrollvalue, setScrollvalue] = useState(null)
    const mainContainer = useRef(null)
    const widhtref1 = useRef(null);
    const widhtref2 = useRef(null);
    const widhtref3 = useRef(null);
    const widhtref4 = useRef(null);
    const widhtref5 = useRef(null);
    useEffect(() => {
      let w = widhtref1.current.offsetWidth+widhtref2.current.offsetWidth+widhtref3.current.offsetWidth+widhtref3.current.offsetWidth+widhtref4.current.offsetWidth+widhtref5.current.offsetWidth;
      let a = widhtref1.current.offsetWidth+widhtref2.current.offsetWidth+widhtref3.current.offsetWidth+widhtref3.current.offsetWidth+widhtref4.current.offsetWidth+widhtref5.current.offsetWidth - mainContainer.current.offsetWidth;
      setWidhtvalue(w);
      setScrollvalue(a);
    }, [widhtref1, widhtref2, widhtref3, widhtref4, widhtref5]);
    console.log(widthvalue);
    console.log(Scrollvalue);
    // this area is for framer motion animation 
    const viewelement = useRef(null)
    const { scrollYProgress } = useScroll({
        target: viewelement,
        offset: ["120% end", "end center"]
    });
    const x = useTransform(scrollYProgress, [0, 1], [0, -Scrollvalue]);
    // end here
    return (
        <section className="RecommededBy relative mt-20">
            <img src={require('../../images/dots.png')} alt="" className='absolute top-0 -left-[20px] -z-10 opacity-50 object-cover h-full' />
            <div className="container mx-auto overflow-hidden" ref={mainContainer}>
                <div style={{width: `${widthvalue}px`}}>
                    <motion.div className="flex items-center" style={{x}} ref={viewelement}>
                        <div className='flex items-center pr-10' ref={widhtref1}><h2 className='font-heading text-5xl text-primaryBlack opacity-70'>RecommededBy</h2> <span className='w-[100px]'><img src={arrowsvg} alt="" className='ml-6'/></span></div>
                        <img src={require("../../images/hero-icon2.png")} ref={widhtref5} alt="" className='h-[86px] pr-10'/>
                        <img src={require("../../images/hero-icon1.png")} ref={widhtref2} alt="" className='h-[133px] pr-10'/>
                        <img src={require("../../images/hero-icon3.png")} ref={widhtref3} alt="" className='h-[150px] pr-10'/>
                        <img src={require("../../images/hero-icon4.png")} ref={widhtref4} alt="" className='h-[50px] pr-10'/>
                    </motion.div>
                </div>
            </div>
        </section>
    )
}

export default RecommededBy
