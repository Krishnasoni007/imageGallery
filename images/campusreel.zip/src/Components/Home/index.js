import React from 'react'
import Footer from '../Layout/Footer'
import Header from '../Layout/Header'
import Hero from './Hero'
import Press from './Press'
import RecommededBy from './RecommededBy'
import Video from './Video'
const index = () => {
  return (
      <>
        <Header />
        <Hero />
        <RecommededBy />
        <Video />
        <Press />
        <Footer />
      </>
  )
}

export default index
