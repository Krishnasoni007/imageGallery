import React from 'react'

const Video = () => {
    return (
        <section className='video mt-20 bg-[#F2F2F2] overflow-hidden'>
            <div class="container mx-auto">
                <div className='grid grid-cols-12 gap-6 h-[650px] overflow-hidden'>
                    <div className='col-span-6 py-10'>
                        <h2 className='font-heading text-8xl mb-4 text-primaryBlack opacity-70'>Videos that Drive Connections <span><img src={require('../../images/stars.png')} alt="" className='inline w-18' /></span></h2>
                        <p className='text-primaryBlack text-lg opacity-60 font-medium tracking-wider w-10/12'>CampusReel's student-driven video content puts students at the forefront of their college communities to build trust, connection and engagement in the digital world.</p>
                        <img src={require('../../images/toing.png')} alt="" className='w-28 rotate-[-5deg] mx-auto' />
                    </div>
                    <div className="col-span-6 relative">
                        <div className='flex gap-6 relative justify-evenly right-[40%]'>
                            <div className="video-line basis-1/4">
                                <div className='flex flex-col'>
                                    <img src="https://images.unsplash.com/photo-1618355281911-84e6ec751d84?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" />
                                    <img src="https://images.unsplash.com/photo-1556807166-18a5c02aa7c4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80" />
                                    <img src="https://images.unsplash.com/photo-1616103195291-42f82fce49af?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=627&q=80" />
                                    <img src="https://images.unsplash.com/photo-1617704935081-ef8b38a07e3b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=715&q=80" />
                                </div>

                                <div className='flex flex-col'>
                                    <img src="https://images.unsplash.com/photo-1618355281911-84e6ec751d84?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" />
                                    <img src="https://images.unsplash.com/photo-1556807166-18a5c02aa7c4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80" />
                                    <img src="https://images.unsplash.com/photo-1616103195291-42f82fce49af?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=627&q=80" />
                                    <img src="https://images.unsplash.com/photo-1617704935081-ef8b38a07e3b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=715&q=80" />
                                </div>
                            </div>
                            <div className="video-line reverse basis-1/4">
                                <div className='flex flex-col'>
                                    <img src="https://images.unsplash.com/photo-1605170444329-61aa23227b07?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=735&q=80" />
                                    <img src="https://images.unsplash.com/photo-1540324155974-7523202daa3f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=715&q=80" />
                                    <img src="https://images.unsplash.com/photo-1649864728442-597a73bc03d3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" />
                                    <img src="https://images.unsplash.com/photo-1552831682-c5c7fc3a5e9d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" />
                                </div>

                                <div className='flex flex-col'>
                                    <img src="https://images.unsplash.com/photo-1605170444329-61aa23227b07?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=735&q=80" />
                                    <img src="https://images.unsplash.com/photo-1540324155974-7523202daa3f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=715&q=80" />
                                    <img src="https://images.unsplash.com/photo-1649864728442-597a73bc03d3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" />
                                    <img src="https://images.unsplash.com/photo-1552831682-c5c7fc3a5e9d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" />
                                </div>
                            </div>        
                            <div className="video-line basis-1/4">
                                <div className='flex flex-col'>
                                    <img src="https://images.unsplash.com/photo-1665028604854-9aef3b7db350?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80" />
                                    <img src="https://images.unsplash.com/photo-1667724874255-4bb232b1d5c0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=735&q=80" />
                                    <img src="https://images.unsplash.com/photo-1604954055722-7f80571fbfc3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1169&q=80" />
                                    <img src="https://images.unsplash.com/photo-1526631880652-71a048b9b492?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" />
                                </div>

                                <div className='flex flex-col'>
                                    <img src="https://images.unsplash.com/photo-1665028604854-9aef3b7db350?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80" />
                                    <img src="https://images.unsplash.com/photo-1667724874255-4bb232b1d5c0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=735&q=80" />
                                    <img src="https://images.unsplash.com/photo-1604954055722-7f80571fbfc3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1169&q=80" />
                                    <img src="https://images.unsplash.com/photo-1526631880652-71a048b9b492?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" />
                                </div>
                            </div>        
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Video
